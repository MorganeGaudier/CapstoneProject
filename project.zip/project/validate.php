<?php
include 'includes/db_connect.php';

$prescriptionID = $_GET['prescription_id'] ?? '';
$token = $_GET['token'] ?? '';

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Validate Prescription</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <?php
    if(!$prescriptionID || !$token){
        echo "<h2>❌ Invalid QR code</h2>";
    } else {
        $stmt = $conn->prepare("SELECT * FROM prescriptions WHERE prescription_id=? AND token=?");
        $stmt->bind_param("ss", $prescriptionID, $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows === 0){
            echo "<h2>❌ Prescription not found or invalid token</h2>";
        } else {
            $prescription = $result->fetch_assoc();
            if($prescription['status'] === 'dispensed'){
                echo "<h2>✅ Already Dispensed</h2>";
            } else {
                echo "<h2>✅ Prescription Valid</h2>";
                echo "<p><b>Patient:</b> {$prescription['patient_name']}</p>";
                echo "<p><b>Doctor:</b> {$prescription['doctor_name']}</p>";
                echo "<p><b>Medicine:</b> {$prescription['medicine']}</p>";
                echo "<p><b>Dosage:</b> {$prescription['dosage']}</p>";
            }
        }
    }
    $conn->close();
    ?>
    <a href="index.php">⬅ Back to Home</a>
  </div>
</body>
</html>
