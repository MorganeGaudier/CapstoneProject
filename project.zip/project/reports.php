<?php
include 'includes/db_connect.php';

$doctorQuery = $conn->query("SELECT doctor_name, COUNT(*) as total FROM prescriptions GROUP BY doctor_name");

$statusQuery = $conn->query("SELECT status, COUNT(*) as total FROM prescriptions GROUP BY status");

$medQuery = $conn->query("SELECT medicine, COUNT(*) as total FROM prescriptions GROUP BY medicine ORDER BY total DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reports</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>📊 System Reports</h1>

    <h2>Prescriptions by Doctor</h2>
    <table>
      <tr>
        <th>Doctor</th>
        <th>Total Prescriptions</th>
      </tr>
      <?php while($row = $doctorQuery->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['doctor_name']) ?></td>
          <td><?= $row['total'] ?></td>
        </tr>
      <?php endwhile; ?>
    </table>

    <h2>Dispensed vs Pending</h2>
    <table>
      <tr>
        <th>Status</th>
        <th>Total</th>
      </tr>
      <?php while($row = $statusQuery->fetch_assoc()): ?>
        <tr>
          <td><?= ucfirst($row['status']) ?></td>
          <td><?= $row['total'] ?></td>
        </tr>
      <?php endwhile; ?>
    </table>

    <h2>Most Prescribed Medicines</h2>
    <table>
      <tr>
        <th>Medicine</th>
        <th>Total</th>
      </tr>
      <?php while($row = $medQuery->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['medicine']) ?></td>
          <td><?= $row['total'] ?></td>
        </tr>
      <?php endwhile; ?>
    </table>

    <div style="margin-top:20px;">
      <a href="index.php">⬅ Back to Home</a>
    </div>
  </div>
</body>
</html>
